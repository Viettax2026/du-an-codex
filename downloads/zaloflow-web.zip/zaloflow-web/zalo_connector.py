"""Private QR login workers; no credentials are exposed through HTTP."""
import json
import os
import shutil
import subprocess
import threading
import time
import uuid
from pathlib import Path


class QRConnector:
    def __init__(self, instance_path, source_path,node_binary=None):
        self.root = Path(instance_path) / 'zalo'
        self.worker = Path(source_path) / 'connector' / 'qr-login.mjs'
        self.lock = threading.Lock()
        self.jobs = {}
        self.node_binary=node_binary

    def node(self):
        bundled=self.worker.parent.parent/'runtime'/'node.exe'
        return str(self.node_binary or bundled) if self.node_binary or bundled.is_file() else shutil.which('node')

    def worker_options(self):
        environment={key:os.environ[key] for key in ('PATH','SystemRoot','SYSTEMROOT','WINDIR','TEMP','TMP','USERPROFILE','LOCALAPPDATA','APPDATA') if key in os.environ}
        environment.setdefault('PATH','/usr/bin:/bin');environment['NODE_ENV']='production'
        return dict(env=environment,creationflags=subprocess.CREATE_NO_WINDOW if os.name=='nt' else 0)

    def stop_workers(self):
        """Stop QR workers on desktop close without deleting saved sessions."""
        with self.lock:
            jobs=list(self.jobs.values());self.jobs.clear()
        for process in jobs:
            if process.poll() is None:
                process.terminate()
                try:process.wait(timeout=3)
                except subprocess.TimeoutExpired:process.kill();process.wait()

    def available(self):
        return bool(self.node() and (self.worker.parent / 'node_modules' / 'zca-js').is_dir())

    @staticmethod
    def write_json(path, data):
        temporary = path.with_name(path.name + '.tmp')
        with open(temporary, 'w', encoding='utf-8', opener=lambda p, f: os.open(p, f, 0o600)) as stream:
            json.dump(data, stream)
        temporary.replace(path)

    def account_path(self, user_id, account_id):
        return self.root / str(int(user_id)) / str(int(account_id))

    def status(self, user_id, account_id):
        base = self.account_path(user_id, account_id)
        try:
            pointer = json.loads((base / 'current.json').read_text(encoding='utf-8'))
            run_id = str(uuid.UUID(pointer['run_id']))
            result = json.loads((base / run_id / 'status.json').read_text(encoding='utf-8'))
            if result.get('state') in ('loading', 'qr', 'scanned'):
                if time.time() - result.get('updated_at', 0) > 180:
                    return {'state': 'error', 'message': 'Phiên đăng nhập đã dừng. Vui lòng tạo mã mới.'}
                if result.get('state') == 'qr' and time.time() >= result.get('expires_at', 0):
                    return {'state': 'expired', 'message': 'Mã QR đã hết hạn.'}
            # Explicit allowlist; a session file or upstream token cannot enter a response.
            return {key: result[key] for key in ('state', 'image', 'expires_at', 'display_name',
                    'message', 'verified_at') if key in result}
        except (OSError, ValueError, KeyError, TypeError):
            return {'state': 'disconnected'}

    def start(self, user_id, account_id):
        with self.lock:
            if not self.available():
                raise RuntimeError('VPS chưa cài bộ kết nối QR. Cần cài Node.js và npm ci trong thư mục connector.')
            # Reap completed children and bound the amount of simultaneous network work.
            self.jobs = {key: process for key, process in self.jobs.items() if process.poll() is None}
            account = (user_id, account_id)
            if account in self.jobs:
                return self.status(*account)
            if len(self.jobs) >= 10:
                raise RuntimeError('Máy chủ đang có nhiều phiên đăng nhập. Vui lòng thử lại sau.')
            self.root.mkdir(parents=True, exist_ok=True, mode=0o700)
            key_path = self.root / 'auth.key'
            if not key_path.exists():
                try:
                    fd = os.open(key_path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
                    with os.fdopen(fd, 'wb') as stream:
                        stream.write(os.urandom(32))
                except FileExistsError:
                    pass
            base = self.account_path(*account)
            run_id = str(uuid.uuid4())
            directory = base / run_id
            directory.mkdir(parents=True, mode=0o700)
            initial = {'state': 'loading', 'updated_at': time.time()}
            self.write_json(directory / 'status.json', initial)
            # The child only writes its own run directory, preventing old status races.
            process = subprocess.Popen([self.node(), str(self.worker), str(directory), str(key_path)],
                                       stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                                       stderr=subprocess.DEVNULL, close_fds=True,
                                       **self.worker_options())
            self.jobs[account] = process
            self.write_json(base / 'current.json', {'run_id': run_id})
            return {'state': 'loading'}

    def disconnect(self, user_id, account_id):
        with self.lock:
            process = self.jobs.pop((user_id, account_id), None)
            if process and process.poll() is None:
                process.terminate()
                try:
                    process.wait(timeout=3)
                except subprocess.TimeoutExpired:
                    process.kill()
                    process.wait()
            base = self.account_path(user_id, account_id)
            if base.exists():
                shutil.rmtree(base)

    def message_action(self, user_id, account_id, action, **data):
        if not self.available():
            return {'state':'lookup_failed','lookup_reason':'connector_unavailable'} if action=='resolve' else {'state':'failed'}
        if self.status(user_id, account_id).get('state') != 'connected':
            if action=='resolve':
                return {'state':'lookup_failed','lookup_reason':'session'}
            return {'state': 'failed'}
        try:
            base = self.account_path(user_id, account_id)
            run_id = str(uuid.UUID(json.loads((base / 'current.json').read_text(encoding='utf-8'))['run_id']))
            payload = {'action': action, 'session': str(base / run_id / 'session.enc.json'),
                       'key': str(self.root / 'auth.key'), **data}
            result = subprocess.run([self.node(), str(self.worker.parent / 'message.mjs')],
                input=json.dumps(payload), text=True, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
                timeout=45, encoding='utf-8',**self.worker_options())
            output = json.loads(result.stdout)
            if not isinstance(output,dict):
                raise ValueError('Invalid response')
            public={key: output[key] for key in ('state', 'uid', 'name', 'original_name', 'gender', 'message_id') if key in output}
            if action=='resolve':
                import re
                reasons={'session','network','rate_limited','invalid_response','connector_unavailable','unavailable','recipient_blocked'}
                if output.get('lookup_reason') in reasons:
                    public['lookup_reason']=output['lookup_reason']
                code=str(output.get('lookup_code',''))
                if re.fullmatch(r'-?\d{1,8}|[A-Z][A-Z0-9_]{0,31}',code):
                    public['lookup_code']=code
            else:
                from campaign_errors import diagnostics
                public.update(diagnostics(output))
            return public
        except subprocess.TimeoutExpired:
            if action=='resolve':
                return {'state':'lookup_failed','lookup_reason':'network'}
            return {'state': 'unknown' if action in ('send', 'friend', 'alias') else 'failed'}
        except (OSError, ValueError, KeyError, TypeError) as error:
            if action=='resolve':
                reason='session' if isinstance(error,KeyError) else 'connector_unavailable' if isinstance(error,OSError) else 'invalid_response'
                return {'state':'lookup_failed','lookup_reason':reason}
            return {'state': 'unknown' if action in ('send', 'friend', 'alias') else 'failed'}

    def forward_group_messages(self,user_id,account_id,group_ids,message):
        unknown=[dict(uid=uid,state='unknown',reason='batch_uncertain') for uid in group_ids]
        if not self.available() or self.status(user_id,account_id).get('state')!='connected':return unknown
        try:
            base=self.account_path(user_id,account_id)
            run_id=str(uuid.UUID(json.loads((base/'current.json').read_text(encoding='utf-8'))['run_id']))
            payload=dict(group_ids=group_ids,message=message,session=str(base/run_id/'session.enc.json'),key=str(self.root/'auth.key'))
            result=subprocess.run([self.node(),str(self.worker.parent/'forward-groups.mjs')],input=json.dumps(payload),text=True,
                stdout=subprocess.PIPE,stderr=subprocess.DEVNULL,timeout=45,encoding='utf-8',**self.worker_options())
            output=json.loads(result.stdout)
            if not isinstance(output,dict) or output.get('state')!='ok' or not isinstance(output.get('rows'),list):return unknown
            rows={}
            for row in output['rows']:
                if not isinstance(row,dict) or row.get('uid') not in group_ids or row.get('uid') in rows:return unknown
                state=row.get('state') if row.get('state') in ('sent','failed','unknown') else 'unknown'
                reason=row.get('reason') if row.get('reason') in ('group_not_joined','batch_accepted','batch_refused','batch_uncertain') else 'batch_uncertain'
                message_id=str(row.get('message_id',''))
                if state=='sent' and not re.fullmatch(r'\d{1,30}(?:,\d{1,30}){0,49}',message_id):state='unknown'
                rows[row['uid']]=dict(uid=row['uid'],state=state,reason=reason,message_id=message_id if state=='sent' else '')
            return [rows.get(row['uid'],row) for row in unknown]
        except (OSError,ValueError,KeyError,TypeError,subprocess.TimeoutExpired):return unknown

    def scan_action(self, user_id, account_id, kind, offset=0, group_id='', cursor=None):
        if not self.available():
            return {'state':'error','reason':'connector_unavailable'}
        if self.status(user_id, account_id).get('state') != 'connected':
            return {'state':'error','reason':'session'}
        try:
            base = self.account_path(user_id, account_id)
            run_id = str(uuid.UUID(json.loads((base / 'current.json').read_text(encoding='utf-8'))['run_id']))
            payload = dict(kind=kind, offset=offset, group_id=group_id, cursor=cursor or {},
                session=str(base / run_id / 'session.enc.json'), key=str(self.root / 'auth.key'))
            result = subprocess.run([self.node(), str(self.worker.parent / 'scan.mjs')],
                input=json.dumps(payload),text=True,stdout=subprocess.PIPE,stderr=subprocess.DEVNULL,
                timeout=45,encoding='utf-8',**self.worker_options())
            output = json.loads(result.stdout)
            if not isinstance(output,dict) or output.get('state') != 'ok':
                reason=output.get('reason') if isinstance(output,dict) else ''
                return {'state':'error','reason':reason if reason in ('session','network','rate_limited','connector_unavailable') else 'unavailable'}
            # Further row validation and allowlisting happens before persistence.
            return {key:output[key] for key in ('state','rows','has_more','next_offset','total','limited','source_name','accessible_total','limit_reason','viewer_role','member_source','members_hidden','cursor','diagnostics') if key in output}
        except (OSError,ValueError,KeyError,TypeError,subprocess.TimeoutExpired):
            return {'state':'error','reason':'network'}
