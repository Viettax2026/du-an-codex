"""Vietnam-time campaign windows and a serialized, restart-safe scheduler."""
import calendar
import re
import time
import signal
from threading import Event
from datetime import date, datetime, timedelta, timezone, time as wall_time
from pathlib import Path
from zoneinfo import ZoneInfo

import click
from flask import flash, g, redirect, render_template, request, url_for
from werkzeug.exceptions import HTTPException

from campaign_exclusions import contact_is_excluded
from rich_message import load_styles
from campaign_limits import usage, available_actions
from campaign_duplicates import recent_message, DuplicateMessageBlocked
from campaign_edits import next_send_id

TZ = ZoneInfo('Asia/Ho_Chi_Minh')
ACTION_RECOVERY_GRACE_SECONDS=90  # Longer than the connector's 45-second process timeout.
CONFIG_COLUMNS = ('schedule_kind','schedule_date','schedule_time','schedule_weekdays',
                  'schedule_monthday','schedule_continue','schedule_stop_enabled','schedule_stop','schedule_skip_sunday')


def local_now():
    return datetime.now(TZ)


def initialize_schedule(db):
    fields = {'schedule_enabled':'INTEGER NOT NULL DEFAULT 0', 'schedule_kind':"TEXT NOT NULL DEFAULT 'daily'",
              'schedule_date':"TEXT NOT NULL DEFAULT ''", 'schedule_time':"TEXT NOT NULL DEFAULT '08:00'",
              'schedule_weekdays':"TEXT NOT NULL DEFAULT ''", 'schedule_monthday':'INTEGER NOT NULL DEFAULT 1',
              'schedule_continue':'INTEGER NOT NULL DEFAULT 1', 'schedule_skip_sunday':'INTEGER NOT NULL DEFAULT 0', 'schedule_stop_enabled':'INTEGER NOT NULL DEFAULT 0',
              'schedule_stop':"TEXT NOT NULL DEFAULT '17:00'", 'schedule_first_day':'TEXT',
              'schedule_carry':'INTEGER NOT NULL DEFAULT 0', 'schedule_error':"TEXT NOT NULL DEFAULT ''",
              'schedule_status':"TEXT NOT NULL DEFAULT 'Chưa bật lịch'", 'schedule_revision':'INTEGER NOT NULL DEFAULT 0',
              'schedule_wait_until':"TEXT NOT NULL DEFAULT ''",'schedule_wait_message':"TEXT NOT NULL DEFAULT ''"}
    fields.update(schedule_started_revision='INTEGER NOT NULL DEFAULT -1',schedule_limit_notice="TEXT NOT NULL DEFAULT ''")
    present={row['name'] for row in db().execute('PRAGMA table_info(campaigns)')}
    for name,definition in fields.items():
        if name not in present:
            db().execute(f'ALTER TABLE campaigns ADD COLUMN {name} {definition}')
    present={row['name'] for row in db().execute('PRAGMA table_info(message_sends)')}
    if 'scheduled' not in present:
        db().execute('ALTER TABLE message_sends ADD COLUMN scheduled INTEGER NOT NULL DEFAULT 0')
    if 'schedule_turn_finished' not in present:
        db().execute('ALTER TABLE message_sends ADD COLUMN schedule_turn_finished INTEGER NOT NULL DEFAULT 0')
    if 'schedule_completed_at' not in present:
        db().execute('ALTER TABLE message_sends ADD COLUMN schedule_completed_at TEXT')
    if 'schedule_skip_reason' not in present:
        db().execute("ALTER TABLE message_sends ADD COLUMN schedule_skip_reason TEXT NOT NULL DEFAULT ''")
    if 'schedule_turn_finished' not in present or 'schedule_completed_at' not in present:
        db().execute('''UPDATE message_sends SET schedule_turn_finished=1,schedule_completed_at=created_at
            WHERE scheduled=1 AND state NOT IN ('prepared','sending','unknown')
            AND friend_state NOT IN ('prepared','sending','unknown') AND alias_state NOT IN ('prepared','sending','unknown')''')
    db().commit()


def resume_failed_action_blocks(db,manager):
    db().execute('BEGIN IMMEDIATE')
    errors=(
        'Kết quả hành động chưa xác định. Kiểm tra hội thoại Zalo rồi lưu lại lịch để tiếp tục; không tự gửi lại lần đó.',
        'Có lần gửi bị gián đoạn. Kiểm tra hội thoại Zalo và lịch sử trước khi tiếp tục.',
    )
    rows=db().execute('''SELECT c.id FROM campaigns c WHERE c.schedule_enabled=1 AND c.deleted_at IS NULL
        AND c.schedule_error IN (?,?) AND EXISTS (SELECT 1 FROM message_sends s WHERE s.campaign_id=c.id
        AND s.scheduled=1 AND (s.state IN ('unknown','sending') OR s.friend_state IN ('unknown','sending')
                             OR s.alias_state IN ('unknown','sending')))''',errors).fetchall()
    for row in rows:
        db().execute("UPDATE campaigns SET schedule_error='',schedule_revision=schedule_revision+1,schedule_status='Chờ bỏ qua lượt lỗi và tiếp tục theo lịch' WHERE id=?",(row['id'],))
        manager.event(row['id'],'schedule_resume','Tiếp tục sau cập nhật: ghi nhận lượt lỗi/chưa xác định, bỏ qua và nghỉ theo cài đặt; không tự thực hiện lại lượt đó.')
    db().commit()


def resume_legacy_lookup_blocks(db,manager):
    """Retry read-only lookups stopped by the previous all-or-nothing policy."""
    db().execute('BEGIN IMMEDIATE')
    for campaign in db().execute("SELECT id,schedule_error FROM campaigns WHERE schedule_enabled=1 AND deleted_at IS NULL AND schedule_error!=''").fetchall():
        missing=r'Không tìm được Zalo của [0-9]{8,15}\. Kiểm tra data rồi lưu lại lịch\.'
        unavailable=r'Không thể tra cứu Zalo của [0-9]{8,15} lúc này\. Kiểm tra kết nối, giới hạn tra cứu hoặc đăng nhập Zalo rồi lưu lại lịch\.'
        if re.fullmatch(missing,campaign['schedule_error']) or re.fullmatch(unavailable,campaign['schedule_error']):
            db().execute("UPDATE campaigns SET schedule_error='',schedule_status='Chờ tra cứu lại và tiếp tục theo lịch',schedule_revision=schedule_revision+1 WHERE id=?",(campaign['id'],))
            manager.event(campaign['id'],'schedule_resume','Tiếp tục lịch sau cập nhật: bỏ qua số tra cứu không tìm được, nghỉ theo cài đặt rồi xử lý số kế tiếp. Giữ nguyên các lượt đã gửi.')
    db().commit()


def schedule_values(form, account_id):
    enabled = int(form.get('schedule_enabled')=='yes')
    if not enabled:
        return {'schedule_enabled':0}
    if not account_id:
        raise ValueError('Chọn tài khoản gửi trước khi bật lịch chạy.')
    kind=form.get('schedule_kind','daily')
    if kind not in ('daily','weekly','monthly'):
        raise ValueError('Chọn lịch hằng ngày, theo tuần hoặc theo tháng.')
    try:
        anchor=date.fromisoformat(form.get('schedule_date',''))
        if not 2020 <= anchor.year <= 2100:
            raise ValueError()
        start=form.get('schedule_time','')
        stop=form.get('schedule_stop','17:00')
        if not re.fullmatch(r'\d{2}:\d{2}',start) or not re.fullmatch(r'\d{2}:\d{2}',stop):
            raise ValueError()
        start_time=wall_time.fromisoformat(start);stop_time=wall_time.fromisoformat(stop)
        monthday=int(form.get('schedule_monthday',str(anchor.day)))
        weekdays=sorted(set(int(day) for day in form.getlist('schedule_weekdays'))) if kind=='weekly' else [anchor.weekday()]
        if not 1 <= monthday <= 31 or not weekdays or any(day not in range(7) for day in weekdays):
            raise ValueError()
    except (ValueError,TypeError):
        raise ValueError('Kiểm tra ngày chạy, giờ chạy và các ngày trong tuần/tháng.') from None
    stop_enabled=int(form.get('schedule_stop_enabled')=='yes')
    if not stop_enabled and start_time >= wall_time(23,59):
        raise ValueError('Giờ chạy cần trước 23:59 khi không bật giờ dừng.')
    if stop_enabled and stop_time <= start_time:
        raise ValueError('Giờ dừng phải sau giờ chạy trong cùng ngày (UTC+7).')
    values=dict(schedule_enabled=enabled,schedule_kind=kind,schedule_date=anchor.isoformat(),schedule_time=start,
                schedule_weekdays=','.join(map(str,weekdays)),schedule_monthday=monthday,
                schedule_continue=int(form.get('schedule_continue')=='yes'),schedule_stop_enabled=stop_enabled,schedule_stop=stop)
    if form.get('schedule_skip_sunday_present')=='yes' or 'schedule_skip_sunday' in form:
        values['schedule_skip_sunday']=int(form.get('schedule_skip_sunday')=='yes')
    return values


def save_schedule(db, campaign_id, form, account_id):
    if form.get('schedule_present')!='yes':
        return
    values=schedule_values(form,account_id)
    old=db().execute('SELECT * FROM campaigns WHERE id=?',(campaign_id,)).fetchone()
    skip_sunday=values.get('schedule_skip_sunday',old['schedule_skip_sunday'])
    if values['schedule_enabled'] and skip_sunday and values['schedule_kind']=='weekly' and values['schedule_weekdays']=='6':
        raise ValueError('Đã bật Không chạy ngày Chủ nhật. Chọn ít nhất một ngày từ Thứ 2 đến Thứ 7 cho lịch tuần.')
    # Adding/removing a rest day must not discard already unfinished data.
    unchanged=bool(old['schedule_enabled'] and values['schedule_enabled'] and all(old[name]==value for name,value in values.items() if name!='schedule_skip_sunday'))
    db().execute('UPDATE campaigns SET '+','.join(name+'=?' for name in values)+''',
        schedule_first_day=?,schedule_carry=?,schedule_error='',schedule_revision=schedule_revision+1,schedule_status=? WHERE id=?''',
        (*values.values(),old['schedule_first_day'] if unchanged else None,old['schedule_carry'] if unchanged else 0,
         'Chờ đến giờ chạy' if values['schedule_enabled'] else 'Chưa bật lịch',campaign_id))
    if values['schedule_enabled']:
        stop=values['schedule_stop'] if values['schedule_stop_enabled'] else '23:59'
        kind={'daily':'Hằng ngày','weekly':'Theo tuần','monthly':'Theo tháng'}[values['schedule_kind']]
        recurrence=''
        if values['schedule_kind']=='weekly':
            names=('Thứ 2','Thứ 3','Thứ 4','Thứ 5','Thứ 6','Thứ 7','Chủ nhật')
            recurrence=' · '+', '.join(names[int(day)] for day in values['schedule_weekdays'].split(','))
        elif values['schedule_kind']=='monthly':
            recurrence=f" · Ngày {values['schedule_monthday']} mỗi tháng"
        account=db().execute('SELECT name FROM zalo_accounts WHERE id=? AND user_id=?',(account_id,old['user_id'])).fetchone()
        skipped_day=' · Không chạy ngày Chủ nhật' if skip_sunday else ''
        detail=f"Lưu lịch: {kind}{recurrence} · Từ {values['schedule_date']} · {values['schedule_time']}–{stop} (24 giờ, UTC+7){skipped_day} · Tài khoản: {account['name'] if account else account_id}."
    elif old['schedule_enabled']:
        detail='Tắt lịch chạy tự động. Các thao tác gửi thủ công vẫn cần xác nhận.'
    else:
        return
    db().execute("INSERT INTO campaign_events(campaign_id,kind,detail) VALUES (?,'schedule',?)",(campaign_id,detail))


def active_window(campaign, now):
    now=now.astimezone(TZ)
    if not campaign['schedule_enabled'] or campaign['paused'] or campaign['deleted_at'] or campaign['schedule_error']:
        return False
    try:
        anchor=date.fromisoformat(campaign['schedule_date'])
        today=now.date()
        if campaign['schedule_skip_sunday'] and today.weekday()==6:
            return False
        if today<anchor:
            return False
        regular=campaign['schedule_kind']=='daily'
        if campaign['schedule_kind']=='weekly':
            regular=today.weekday() in {int(day) for day in campaign['schedule_weekdays'].split(',')}
        if campaign['schedule_kind']=='monthly':
            regular=today.day==min(campaign['schedule_monthday'],calendar.monthrange(today.year,today.month)[1])
        carry=bool(campaign['schedule_continue'] and campaign['schedule_carry'] and campaign['schedule_first_day'] and today>=date.fromisoformat(campaign['schedule_first_day']))
        if not regular and not carry:
            return False
        start=wall_time.fromisoformat(campaign['schedule_time'])
        stop=wall_time.fromisoformat(campaign['schedule_stop']) if campaign['schedule_stop_enabled'] else wall_time(23,59)
        if now.time().replace(tzinfo=None)<start or now.time().replace(tzinfo=None)>=stop:
            return False
        return True
    except (ValueError,TypeError):
        return False


def manual_schedule_block(campaign, now=None):
    """Manual confirmation must not bypass a campaign's enabled schedule."""
    if not campaign['schedule_enabled']:
        return ''
    if campaign['schedule_error']:
        return 'Lịch đang tạm dừng: '+campaign['schedule_error']+' Kiểm tra và lưu lại lịch trước khi thực hiện hành động.'
    now=(now or local_now()).astimezone(TZ)
    if campaign['schedule_skip_sunday'] and now.weekday()==6:
        return 'Lịch đã bật Không chạy ngày Chủ nhật (giờ Việt Nam, UTC+7). Gửi tin, kết bạn và đổi tên sẽ chờ ngày chạy hợp lệ tiếp theo.'
    if active_window(campaign,now):
        stamp=now.astimezone(timezone.utc).replace(tzinfo=None,microsecond=0).isoformat(' ')
        if campaign['schedule_wait_until'] and campaign['schedule_wait_until']>stamp:
            return campaign['schedule_wait_message']+' '+wait_label(campaign['schedule_wait_until'])
        return ''
    stop=campaign['schedule_stop'] if campaign['schedule_stop_enabled'] else '23:59'
    return (f"Ngoài lịch chạy đã lưu: {campaign['schedule_time']}–{stop}, từ {campaign['schedule_date']} "
            '(giờ Việt Nam, UTC+7). Gửi tin, kết bạn và đổi tên chỉ được thực hiện trong lịch đã bật.')


def wait_label(stamp):
    local=datetime.fromisoformat(stamp).replace(tzinfo=timezone.utc).astimezone(TZ)
    return 'Tiếp tục lúc '+local.strftime('%H:%M:%S %d/%m/%Y')+' (UTC+7).'


class CampaignScheduler:
    def __init__(self,app,db,manager,connector,audience):
        self.app,self.db,self.manager,self.connector,self.audience=app,db,manager,connector,audience
        self.stopping=False

    def status(self,campaign_id,text):
        self.status_text(campaign_id,text)
        self.db().commit()

    def rest(self,campaign,now,message=None,seconds=None):
        """Persist spacing between recipients without a send/quota attempt."""
        seconds=campaign['interval_seconds'] if seconds is None else seconds
        instant=now().astimezone(timezone.utc)
        if instant.microsecond:
            instant+=timedelta(seconds=1)
        until=(instant+timedelta(seconds=seconds)).replace(tzinfo=None,microsecond=0).isoformat(' ') if seconds else ''
        text=message or f'{self.prefix(campaign)} – Nghỉ {seconds} giây theo cài đặt trước khi xử lý số điện thoại kế tiếp.'
        self.db().execute('UPDATE campaigns SET schedule_wait_until=?,schedule_wait_message=?,schedule_status=? WHERE id=?',
            (until,text if until else '',text+' '+wait_label(until) if until else 'Tiếp tục số điện thoại kế tiếp',campaign['id']))
        if seconds:
            self.manager.event(campaign['id'],'schedule_rest',text+' '+wait_label(until))

    def prefix(self,campaign,account_id=None):
        account=self.db().execute('SELECT name FROM zalo_accounts WHERE id=? AND user_id=?',
            (account_id or campaign['account_id'],campaign['user_id'])).fetchone()
        return f'{account["name"] if account else "Tài khoản"} – {campaign["name"]}'

    def limit_notice(self,campaign,budgets):
        labels={'send':('send_message','Nhắn tin người lạ'),'friend':('send_friend','Kết bạn'),'alias':('rename_enabled','Đổi tên Zalo')}
        blocked=[]
        for action,(enabled,label) in labels.items():
            item=budgets[action]
            if campaign[enabled] and item['blocked']:
                scope=f'trong ngày {item["day_used"]}/{item["day_limit"]}' if item['day_limit'] and item['day_used']>=item['day_limit'] else f'trong {item["minutes"]} phút {item["hour_used"]}/{item["hour_limit"]}'
                blocked.append(f'{label}: đạt giới hạn {scope}')
        text='; '.join(blocked)
        previous=self.db().execute('SELECT schedule_limit_notice FROM campaigns WHERE id=?',(campaign['id'],)).fetchone()[0]
        if text!=previous:
            self.db().execute('UPDATE campaigns SET schedule_limit_notice=? WHERE id=?',(text,campaign['id']))
            if text:
                policy='Tạm bỏ qua hành động đạt giới hạn, tiếp tục các hành động còn hạn mức; phần còn thiếu sẽ chờ hạn mức để chạy tiếp.' if campaign['limits_continue'] else 'Chờ hạn mức để tiếp tục chiến dịch.'
                self.manager.event(campaign['id'],'schedule_limit',f'{self.prefix(campaign)} – {text}. {policy}')
            elif previous:
                self.manager.event(campaign['id'],'schedule_limit_resume',f'{self.prefix(campaign)} – Hạn mức đã có trở lại; tiếp tục các hành động còn thiếu.')

    def finish_turn(self,campaign,send_id,now):
        """Finish a recipient's currently available actions, then rest once.

        Blocked actions remain prepared for a later budget window. They must not
        be declared complete or discarded merely because another action ran.
        The caller commits this together with the final action's result.
        """
        row=self.db().execute('SELECT * FROM message_sends WHERE id=? AND campaign_id=?',(send_id,campaign['id'])).fetchone()
        if row['schedule_skip_reason']:
            return False
        states={'send':row['state'],'friend':row['friend_state'],'alias':row['alias_state']}
        if row['schedule_turn_finished'] or 'sending' in states.values() or ('unknown' in states.values() and not row['continue_after_edit']):
            return False
        budgets=usage(self.db,campaign)
        self.limit_notice(campaign,budgets)
        available=available_actions(campaign,budgets,check_interval=False)
        pending={action for action,state in states.items() if state=='prepared'}
        if pending & available:
            self.status_text(campaign['id'],'Đang chạy theo lịch')
            return False
        self.db().execute('UPDATE message_sends SET schedule_turn_finished=1 WHERE id=?',(send_id,))
        phone=row['recipient_phone'] or self.db().execute('SELECT phone FROM contacts WHERE id=?',(row['contact_id'],)).fetchone()[0]
        if not pending:
            if row['state']=='failed' and self.db().execute("SELECT 1 FROM campaign_attempts WHERE send_id=? AND action='send' AND error_reason='stranger_messages_blocked'",(send_id,)).fetchone():
                self.db().execute("UPDATE message_sends SET schedule_skip_reason='Bỏ qua bước nhắn tin: người nhận chặn tin nhắn từ người lạ. Các bước còn lại đã được xử lý.' WHERE id=?",(send_id,))
            changed=self.db().execute('UPDATE message_sends SET schedule_completed_at=CURRENT_TIMESTAMP WHERE id=? AND schedule_completed_at IS NULL',(send_id,)).rowcount
            if changed:
                note=' · Có hành động chưa xác định, cần kiểm tra Zalo; không tự gửi lại.' if 'unknown' in states.values() else ' · Có hành động thất bại, xem kết quả chi tiết.' if 'failed' in states.values() else ' · Đã ghi nhận bỏ qua, chưa gửi tin.' if not row['recipient_id'] else ''
                self.manager.event(campaign['id'],'schedule_complete',f'{self.prefix(campaign,row["account_id"])} – Hoàn thành xử lý {phone}{note}')
        else:
            self.manager.event(campaign['id'],'schedule_pending_limits',f'{self.prefix(campaign,row["account_id"])} – Đã xử lý các hành động còn hạn mức của {phone}; các hành động chưa thực hiện chờ hạn mức để chạy tiếp.')
        self.rest(campaign,now)
        return True

    def status_text(self,campaign_id,text):
        self.db().execute('UPDATE campaigns SET schedule_status=? WHERE id=?',(text,campaign_id))

    def skip_problem(self,campaign,send_id,now):
        """Preserve failed/unknown results and consumed attempts; abandon this recipient."""
        row=self.db().execute('SELECT * FROM message_sends WHERE id=? AND campaign_id=? AND scheduled=1',
            (send_id,campaign['id'])).fetchone()
        if row is None or row['schedule_skip_reason']:
            return False
        if row['continue_after_edit'] and 'prepared' in (row['state'],row['friend_state'],row['alias_state']):
            self.manager.event(campaign['id'],'schedule_pending_after_error',f'Bản gửi #{send_id}: giữ kết quả bước lỗi/chưa xác định, tiếp tục các bước chưa thực hiện theo cấu hình đã sửa; không thử lại bước cũ.')
            self.rest(campaign,now);return True
        phone=row['recipient_phone'] or self.db().execute('SELECT phone FROM contacts WHERE id=?',(row['contact_id'],)).fetchone()[0]
        unknown='unknown' in (row['state'],row['friend_state'],row['alias_state'])
        reason=f'Bỏ qua {phone}: '+('có hành động chưa xác định kết quả' if unknown else 'có hành động thất bại')+'. Không tự thực hiện lại; tiếp tục số điện thoại kế tiếp.'
        self.db().execute('''UPDATE message_sends SET schedule_skip_reason=?,schedule_turn_finished=1,
            schedule_completed_at=CURRENT_TIMESTAMP,
            state=CASE WHEN state='prepared' THEN 'not_requested' ELSE state END,
            friend_state=CASE WHEN friend_state='prepared' THEN 'not_requested' ELSE friend_state END,
            alias_state=CASE WHEN alias_state='prepared' THEN 'not_requested' ELSE alias_state END WHERE id=?''',(reason,send_id))
        self.manager.event(campaign['id'],'schedule_action_skip',f'{self.prefix(campaign,row["account_id"])} – {reason}')
        self.rest(campaign,now)
        return True

    def recover_problem(self,campaign,guard,now):
        """Resume past uncertain outcomes without treating a live claim as abandoned."""
        self.db().execute('BEGIN IMMEDIATE')
        try:
            campaign=self.manager.owned(campaign['id']);guard(campaign)
            row=self.db().execute('''SELECT * FROM message_sends s WHERE campaign_id=? AND scheduled=1 AND schedule_skip_reason=''
                AND (continue_after_edit=0 OR state='sending' OR friend_state='sending' OR alias_state='sending')
                AND (state IN ('unknown','sending') OR (state='failed' AND NOT EXISTS (
                    SELECT 1 FROM campaign_attempts a WHERE a.send_id=s.id AND a.action='send' AND a.error_reason='stranger_messages_blocked'))
                     OR friend_state IN ('failed','unknown','sending') OR alias_state IN ('failed','unknown','sending')) ORDER BY id LIMIT 1''',(campaign['id'],)).fetchone()
            if row is None:
                self.db().rollback();return False
            columns={'send':'state','friend':'friend_state','alias':'alias_state'}
            sending=[action for action,column in columns.items() if row[column]=='sending']
            cutoff=datetime.now(timezone.utc).replace(tzinfo=None)-timedelta(seconds=ACTION_RECOVERY_GRACE_SECONDS)
            for action in sending:
                attempt=self.db().execute('SELECT created_at FROM campaign_attempts WHERE send_id=? AND action=?',(row['id'],action)).fetchone()
                started=datetime.fromisoformat(attempt['created_at'] if attempt else row['created_at'])
                if started>cutoff:
                    self.status_text(campaign['id'],'Đang chờ kết quả lượt đã bắt đầu; chưa thực hiện lại.')
                    self.db().commit();return True
            for action in sending:
                self.db().execute(f"UPDATE message_sends SET {columns[action]}='unknown' WHERE id=?",(row['id'],))
                self.manager.result(campaign['id'],action,row['id'],'unknown')
            self.skip_problem(campaign,row['id'],now)
            self.db().commit();return True
        except BaseException:
            self.db().rollback();raise

    def lookup_failure(self,campaign,person,account,result,guard,now):
        self.db().execute('BEGIN IMMEDIATE')
        try:
            campaign=self.manager.owned(campaign['id']);guard(campaign)
            person=next((p for p in self.audience(campaign) if p['id']==person['id']),None)
            if person is None or self.db().execute('SELECT 1 FROM message_sends WHERE campaign_id=? AND contact_id=?',(campaign['id'],person['id'])).fetchone():
                self.db().rollback();return
            reason=result.get('lookup_reason','unavailable')
            code=str(result.get('lookup_code',''))
            code=' (mã '+code+')' if re.fullmatch(r'-?\d{1,8}|[A-Z][A-Z0-9_]{0,31}',code) else ''
            if reason in ('session','connector_unavailable'):
                text='Phiên Zalo không đăng nhập được; cần đăng nhập QR lại' if reason=='session' else 'Bộ kết nối Zalo trên VPS chưa sẵn sàng'
                raise ValueError(text+code+'. Kiểm tra rồi lưu lại lịch.')
            if reason in ('network','rate_limited','invalid_response'):
                labels={'network':'Kết nối tra cứu bị gián đoạn','rate_limited':'Zalo đang giới hạn tra cứu','invalid_response':'Phản hồi tra cứu chưa hợp lệ'}
                delay=max(campaign['interval_seconds'],900 if reason=='rate_limited' else 60)
                message=f'{self.prefix(campaign)} – Tìm SĐT {person["phone"]}: {labels[reason]}{code}. Tự thử lại sau {delay} giây.'
                self.manager.event(campaign['id'],'schedule_lookup_result',message)
                self.rest(campaign,now,message,seconds=delay)
                self.db().commit();return
            label='Người nhận bị Zalo chặn' if reason=='recipient_blocked' else 'không tra cứu được người nhận Zalo'
            detail=f'Bỏ qua {person["phone"]}: {label}{code}.'
            self.manager.event(campaign['id'],'schedule_lookup_result',f'{self.prefix(campaign)} – Tìm SĐT: {label}{code} – {person["phone"]}; đã ghi nhận bỏ qua.')
            send_id=self.manager.store_lookup_skip(campaign,person,account,scheduled=True,reason=detail,lookup_state='blocked' if reason=='recipient_blocked' else 'unavailable')
            self.db().execute('UPDATE campaigns SET schedule_first_day=coalesce(schedule_first_day,?),schedule_carry=1 WHERE id=?',(now().astimezone(TZ).date().isoformat(),campaign['id']))
            self.finish_turn(campaign,send_id,now)
            self.db().commit()
        except BaseException:
            self.db().rollback();raise

    def guard(self,campaign_id,revision,now):
        def check(campaign,record=None):
            self.manager.require_active(campaign)
            if self.stopping or campaign['schedule_revision']!=revision or not active_window(campaign,now()):
                raise ValueError('Lịch đã dừng hoặc ngoài giờ chạy.')
            stamp=now().astimezone(timezone.utc).replace(tzinfo=None,microsecond=0).isoformat(' ')
            if campaign['schedule_wait_until'] and campaign['schedule_wait_until']>stamp:
                raise ValueError('Lịch đã dừng hoặc ngoài giờ chạy.')
            if record is not None and (not record['scheduled'] or record['account_id']!=campaign['account_id']):
                raise ValueError('Bản chờ không thuộc tài khoản gửi của lịch hiện tại.')
        return check

    def pending(self,campaign,actions=None):
        columns={'send':'state','friend':'friend_state','alias':'alias_state'}
        selected=set(columns) if actions is None else actions
        if not selected:
            return None
        condition=' OR '.join(columns[a]+"='prepared'" for a in columns if a in selected)
        return self.db().execute(f'''SELECT * FROM message_sends WHERE campaign_id=? AND scheduled=1 AND schedule_skip_reason=''
            AND ({condition}) ORDER BY id LIMIT 1''',(campaign['id'],)).fetchone()

    def dispatch(self,campaign,record,action,guard,now):
        column={'send':'state','friend':'friend_state','alias':'alias_state'}[action]
        if record[column]!='prepared':
            return
        record=self.manager.pending.resolve(campaign,record,action,self.connector,guard)
        # Check private ownership and payload before committing the dispatch claim.
        account=self.db().execute('SELECT id FROM zalo_accounts WHERE id=? AND user_id=? AND deleted_at IS NULL',(record['account_id'],g.user['id'])).fetchone()
        if not account or self.connector.status(g.user['id'],record['account_id']).get('state')!='connected':
            raise ValueError('Tài khoản chưa đăng nhập Zalo. Đăng nhập lại rồi lưu lại lịch.')
        data={'uid':record['recipient_id'],'message':record['message'] if action=='send' else record['friend_message'] if action=='friend' else record['alias']}
        if action=='send':
            styles=load_styles(record['message_styles'],record['message'])
            if styles:
                data['styles']=styles
            if record['media_id']:
                data['attachment']=self.manager.attachment(record['media_id'])
        if not self.manager.claim(campaign['id'],record['id'],action,record,guard=guard):
            return
        try:
            result=self.connector.message_action(g.user['id'],record['account_id'],action,**data)
        except Exception:
            result={'state':'unknown'}
        result=result if isinstance(result,dict) else {'state':'unknown'}
        success={'send':'sent','friend':'friend_requested','alias':'renamed'}[action]
        state=result.get('state') if result.get('state') in (success,'failed','unknown') else 'unknown'
        if action=='send':
            self.db().execute('UPDATE message_sends SET state=?,message_id=? WHERE id=?',(state,str(result.get('message_id',''))[:100] if state=='sent' else '',record['id']))
        else:
            self.db().execute(f'UPDATE message_sends SET {column}=? WHERE id=?',(state,record['id']))
        self.manager.result(campaign['id'],action,record['id'],state,result)
        if state in ('failed','unknown') and not (action=='send' and state=='failed' and result.get('error_reason')=='stranger_messages_blocked'):
            self.skip_problem(campaign,record['id'],now)
        else:
            self.finish_turn(campaign,record['id'],now)
        self.db().commit()

    def skip_known_duplicate(self,campaign,person,account,guard,now):
        self.db().execute('BEGIN IMMEDIATE')
        try:
            campaign=self.manager.owned(campaign['id']);guard(campaign)
            current=next((p for p in self.audience(campaign) if p['id']==person['id']),None)
            if current is None or self.db().execute('SELECT 1 FROM message_sends WHERE campaign_id=? AND contact_id=?',(campaign['id'],person['id'])).fetchone():
                self.db().rollback();return True
            # Recheck changed action settings and the date window after acquiring the write lock.
            if not campaign['send_message'] or campaign['send_friend'] or campaign['rename_enabled']:
                self.db().rollback();return False
            recent=recent_message(self.db,campaign,account['id'],current['phone'])
            if recent is None:
                self.db().rollback();return False
            reason=DuplicateMessageBlocked(recent,campaign['duplicate_days']).description
            self.manager.event(campaign['id'],'schedule_lookup',f'{self.prefix(campaign)} – Xử lý {current["phone"]} · Dùng Zalo đã lưu để kiểm tra trùng lặp.')
            send_id=self.manager.store_preview(campaign,current,account,dict(uid=recent['recipient_id'],name=recent['recipient_name']),scheduled=True,skip_message=True,skip_reason=reason,lookup_state='cached')
            self.manager.event(campaign['id'],'duplicate_skip',f'Bỏ qua khách hàng #{current["id"]}: {reason}')
            self.db().execute('UPDATE campaigns SET schedule_first_day=coalesce(schedule_first_day,?),schedule_carry=1 WHERE id=?',(now().astimezone(TZ).date().isoformat(),campaign['id']))
            self.finish_turn(campaign,send_id,now)
            self.db().commit();return True
        except BaseException:
            self.db().rollback();raise

    def tick_campaign(self,campaign_id,now):
        campaign=self.manager.owned(campaign_id)
        if campaign['campaign_type']=='zalo_group':
            return self.app.extensions['group_campaign_runner'].tick(campaign_id,now)
        if not active_window(campaign,now()):
            return
        stamp=now().astimezone(timezone.utc).replace(tzinfo=None,microsecond=0).isoformat(' ')
        if campaign['schedule_wait_until'] and campaign['schedule_wait_until']>stamp:
            self.status(campaign_id,campaign['schedule_wait_message']+' '+wait_label(campaign['schedule_wait_until']));return
        revision=campaign['schedule_revision'];guard=self.guard(campaign_id,revision,now)
        if not self.app.config['ZALO_QR_ENABLED']:
            raise ValueError('Máy chủ chưa bật kết nối Zalo.')
        account=self.db().execute('SELECT * FROM zalo_accounts WHERE id=? AND user_id=? AND deleted_at IS NULL',(campaign['account_id'],g.user['id'])).fetchone()
        if not account or self.connector.status(g.user['id'],account['id']).get('state')!='connected':
            raise ValueError('Tài khoản chưa đăng nhập Zalo. Đăng nhập lại rồi lưu lại lịch.')
        guard(campaign)
        if campaign['schedule_started_revision']!=revision:
            self.db().execute('UPDATE campaigns SET schedule_started_revision=? WHERE id=?',(revision,campaign_id))
            self.manager.event(campaign_id,'schedule_start',f'{self.prefix(campaign)} – Bắt đầu chiến dịch theo lịch đã lưu.')
            self.db().commit()
        if self.recover_problem(campaign,guard,now):
            return
        # Recover a terminal recipient whose read-only skip was committed just
        # before a restart. Never jump straight to the next phone without rest.
        finished=self.db().execute('''SELECT id FROM message_sends WHERE campaign_id=? AND scheduled=1 AND schedule_turn_finished=0 AND schedule_skip_reason=''
            AND state NOT IN ('prepared','sending','unknown') AND friend_state NOT IN ('prepared','sending','unknown')
            AND alias_state NOT IN ('prepared','sending','unknown') ORDER BY id LIMIT 1''',(campaign_id,)).fetchone()
        if finished:
            self.finish_turn(campaign,finished['id'],now);self.db().commit();return
        budgets=usage(self.db,campaign)
        self.limit_notice(campaign,budgets);self.db().commit()
        allowed_actions=available_actions(campaign,budgets,check_interval=False)
        record=self.pending(campaign,allowed_actions)
        if record is not None:
            # Remove pending actions for recipients who opted out/left the group, without dispatching.
            allowed={person['id'] for person in self.audience(campaign)}
            if record['contact_id'] not in allowed or contact_is_excluded(self.db,g.user['id'],campaign_id,record['contact_id'],record['recipient_id']):
                self.db().execute("UPDATE message_sends SET state=CASE WHEN state='prepared' THEN 'not_requested' ELSE state END,friend_state=CASE WHEN friend_state='prepared' THEN 'not_requested' ELSE friend_state END,alias_state=CASE WHEN alias_state='prepared' THEN 'not_requested' ELSE alias_state END WHERE id=?",(record['id'],))
                self.manager.event(campaign_id,'schedule_skip',f'Bỏ qua bản gửi #{record["id"]}: khách hàng không còn thuộc danh sách được gửi.')
                self.finish_turn(campaign,record['id'],now)
                self.db().commit();return
            for action,column in (('send','state'),('friend','friend_state'),('alias','alias_state')):
                if record[column]=='prepared' and action in allowed_actions:
                    try:
                        self.dispatch(campaign,record,action,guard,now)
                    except DuplicateMessageBlocked:
                        self.manager.skip_duplicate_message(campaign_id,record['id'])
                        self.finish_turn(campaign,record['id'],now);self.db().commit()
                    return  # At most one external action per campaign per tick.
        existing={r['contact_id'] for r in self.db().execute('SELECT contact_id FROM message_sends WHERE campaign_id=?',(campaign_id,))}
        person=next((person for person in self.audience(campaign) if person['id'] not in existing),None)
        if person is None and self.pending(campaign) is None:
            pending_manual=self.db().execute('''SELECT 1 FROM message_sends WHERE campaign_id=? AND schedule_skip_reason=''
                AND (state IN ('prepared','sending','unknown') OR friend_state IN ('prepared','sending','unknown')
                     OR alias_state IN ('prepared','sending','unknown')) LIMIT 1''',(campaign_id,)).fetchone()
            if pending_manual:
                self.status(campaign_id,'Còn bản chờ xác nhận thủ công hoặc kết quả cần kiểm tra.');return
            changed=self.db().execute("UPDATE campaigns SET schedule_carry=0,schedule_status='Đã xử lý hết data hiện tại' WHERE id=? AND (schedule_carry<>0 OR schedule_status<>'Đã xử lý hết data hiện tại')",(campaign_id,)).rowcount
            if changed:
                self.manager.event(campaign_id,'schedule_finished',f'{self.prefix(campaign)} – Đã xử lý hết data hiện tại. Xem kết quả từng hành động để kiểm tra các số đã gửi, bỏ qua hoặc thất bại.')
            self.db().commit();return
        if not allowed_actions or person is None:
            self.status(campaign_id,'Đang chờ giới hạn gửi / khoảng nghỉ')
            return
        if campaign['send_message'] and not campaign['send_friend'] and not campaign['rename_enabled'] and recent_message(self.db,campaign,account['id'],person['phone']):
            if self.skip_known_duplicate(campaign,person,account,guard,now):
                return
        # The lookup is read-only. Revalidate window/settings/consent afterwards in a write transaction.
        self.manager.event(campaign_id,'schedule_lookup',f'{account["name"]} – {campaign["name"]} · Xử lý {person["phone"]} · Tìm Zalo từ số điện thoại.')
        self.db().commit()
        try:
            resolved=self.connector.message_action(g.user['id'],account['id'],'resolve',phone=person['phone'])
        except Exception:
            resolved={'state':'lookup_failed','lookup_reason':'network'}
        if not isinstance(resolved,dict) or resolved.get('state') not in ('resolved','not_found') or (resolved['state']=='resolved' and not re.fullmatch(r'\d{1,30}',str(resolved.get('uid','')))):
            failure=resolved if isinstance(resolved,dict) else {'lookup_reason':'invalid_response'}
            if isinstance(resolved,dict) and resolved.get('state')=='resolved':
                failure={'lookup_reason':'invalid_response'}
            self.lookup_failure(campaign,person,account,failure,guard,now);return
        self.db().execute('BEGIN IMMEDIATE')
        try:
            campaign=self.manager.owned(campaign_id);guard(campaign)
            person=next((p for p in self.audience(campaign) if p['id']==person['id']),None)
            if person is None:
                self.db().rollback();return
            if self.db().execute('SELECT 1 FROM message_sends WHERE campaign_id=? AND contact_id=?',(campaign_id,person['id'])).fetchone():
                self.db().rollback();return
            if resolved['state']=='not_found':
                self.manager.event(campaign_id,'schedule_lookup_result',f'{self.prefix(campaign)} – Tìm SĐT: Không tồn tại Zalo của {person["phone"]}.')
                send_id=self.manager.store_lookup_skip(campaign,person,account,scheduled=True)
                self.db().execute("UPDATE campaigns SET schedule_first_day=coalesce(schedule_first_day,?),schedule_carry=1 WHERE id=?",(now().astimezone(TZ).date().isoformat(),campaign_id))
                self.finish_turn(campaign,send_id,now)
                self.db().commit();return
            self.manager.event(campaign_id,'schedule_lookup_result',f'{self.prefix(campaign)} – Tìm SĐT: Đã tìm thấy SĐT {person["phone"]}: {str(resolved.get("name",""))[:100]}.')
            if contact_is_excluded(self.db,g.user['id'],campaign_id,person['id'],resolved['uid']):
                row=self.db().execute('''INSERT INTO message_sends(id,campaign_id,contact_id,account_id,recipient_id,recipient_name,message,state,friend_state,alias_state,scheduled,recipient_phone,lookup_state,message_skip_reason)
                    VALUES (?,?,?,?,?,?,'','not_requested','not_requested','not_requested',1,?,'resolved','Zalo thuộc danh sách loại trừ.')''',(next_send_id(self.db,'message_sends'),campaign_id,person['id'],account['id'],resolved['uid'],str(resolved.get('name',''))[:100],person['phone']))
                self.db().execute('UPDATE campaigns SET schedule_first_day=coalesce(schedule_first_day,?),schedule_carry=1 WHERE id=?',(now().astimezone(TZ).date().isoformat(),campaign_id))
                self.manager.event(campaign_id,'schedule_skip',f'Bỏ qua khách hàng #{person["id"]}: Zalo thuộc danh sách loại trừ.')
                self.finish_turn(campaign,row.lastrowid,now)
                self.db().commit();return
            recent=recent_message(self.db,campaign,account['id'],person['phone'],resolved['uid']) if campaign['send_message'] else None
            reason=DuplicateMessageBlocked(recent,campaign['duplicate_days']).description if recent else ''
            self.manager.store_preview(campaign,person,account,resolved,scheduled=True,skip_message=bool(recent),skip_reason=reason)
            if recent is not None:
                self.manager.event(campaign_id,'duplicate_skip',f'Bỏ qua tin nhắn cho khách hàng #{person["id"]}: {reason}')
            self.db().execute("UPDATE campaigns SET schedule_first_day=coalesce(schedule_first_day,?),schedule_carry=1,schedule_status='Đang chạy theo lịch' WHERE id=?",(now().astimezone(TZ).date().isoformat(),campaign_id))
            self.db().commit()
        except BaseException:
            self.db().rollback();raise

    def heartbeat(self):
        Path(self.app.config['DATABASE']).with_suffix('.scheduler.heartbeat').write_text(local_now().isoformat())

    def tick(self,now=local_now):
        self.heartbeat()
        license=self.app.extensions.get('desktop_license')
        if license is not None and not license.allowed():
            return
        rows=self.db().execute("SELECT c.id,c.user_id,c.schedule_revision FROM campaigns c JOIN users u ON u.id=c.user_id WHERE u.approval_status='approved' AND c.schedule_enabled=1 AND c.paused=0 AND c.deleted_at IS NULL AND c.schedule_error='' ORDER BY c.id").fetchall()
        for row in rows:
            if self.stopping:
                break
            self.heartbeat()
            g.user=self.db().execute('SELECT id,name,username FROM users WHERE id=?',(row['user_id'],)).fetchone()
            if not self.db().execute("SELECT 1 FROM users WHERE id=? AND approval_status='approved'", (row['user_id'],)).fetchone():
                continue
            try:
                self.tick_campaign(row['id'],now)
            except HTTPException as error:
                self.db().rollback()
                current=self.manager.owned(row['id'],include_deleted=True)
                if current['schedule_revision']!=row['schedule_revision'] or not current['schedule_enabled'] or current['paused'] or current['deleted_at']:
                    continue  # An edit/stop superseded this tick; do not block the new configuration.
                # Quotas/spacing are temporary waits; no new attempts have been claimed.
                if not self.db().execute("SELECT 1 FROM users WHERE id=? AND approval_status='approved'", (row['user_id'],)).fetchone():
                    self.status(row['id'],'Đang chờ duyệt / mở khóa tài khoản')
                elif license is not None and not license.allowed():
                    self.status(row['id'],'Đang chờ kích hoạt / gia hạn bản quyền')
                elif error.code==409:
                    self.status(row['id'],'Đang chờ giới hạn gửi / khoảng nghỉ')
                else:
                    self.block(row['id'],error.description)
            except ValueError as error:
                self.db().rollback()
                current=self.manager.owned(row['id'],include_deleted=True)
                if str(error)!='Lịch đã dừng hoặc ngoài giờ chạy.' and current['schedule_enabled'] and not current['paused'] and not current['deleted_at'] and current['schedule_revision']==row['schedule_revision']:
                    self.block(row['id'],str(error))
            finally:
                self.db().rollback()

    def block(self,campaign_id,message):
        self.db().execute("UPDATE campaigns SET schedule_error=?,schedule_status='Cần kiểm tra' WHERE id=?",(message,campaign_id))
        self.manager.event(campaign_id,'schedule_error',message)
        self.db().commit()


def register_campaign_schedule(app,db,login_required,manager,connector,audience):
    with app.app_context():
        initialize_schedule(db)
        resume_legacy_lookup_blocks(db,manager)
        resume_failed_action_blocks(db,manager)
    scheduler=CampaignScheduler(app,db,manager,connector,audience)
    app.extensions['campaign_scheduler']=scheduler
    app.jinja_env.globals['schedule_today']=lambda: local_now().date().isoformat()
    app.jinja_env.globals['manual_schedule_block']=manual_schedule_block
    def scheduler_online():
        try:
            return time.time()-Path(app.config['DATABASE']).with_suffix('.scheduler.heartbeat').stat().st_mtime<180
        except OSError:
            return False
    app.jinja_env.globals['scheduler_online']=scheduler_online

    @app.route('/campaigns/<int:campaign_id>/schedule',methods=['GET','POST'])
    @login_required
    def campaign_schedule(campaign_id):
        campaign=manager.owned(campaign_id)
        if request.method=='POST':
            try:
                db().execute('BEGIN IMMEDIATE');campaign=manager.owned(campaign_id)
                if request.form.get('schedule_present')!='yes':
                    raise ValueError('Biểu mẫu lịch chưa đầy đủ. Tải lại trang để thử lại.')
                account_id=request.form.get('account_id') or None
                if account_id and not db().execute('SELECT id FROM zalo_accounts WHERE id=? AND user_id=? AND deleted_at IS NULL',(account_id,g.user['id'])).fetchone():
                    raise ValueError('Tài khoản gửi không hợp lệ.')
                save_schedule(db,campaign_id,request.form,account_id)
                db().execute('UPDATE campaigns SET account_id=? WHERE id=?',(account_id,campaign_id))
                db().commit();flash('Đã lưu lịch chạy. Chỉ xử lý những khách hàng chưa gửi trong chiến dịch.','success')
                return redirect(url_for('campaign_detail',campaign_id=campaign_id))
            except ValueError as error:
                db().rollback();flash(str(error),'error')
        return render_template('campaign_schedule.html',campaign=campaign,page='campaigns',accounts=db().execute('SELECT id,name FROM zalo_accounts WHERE user_id=? AND deleted_at IS NULL ORDER BY name',(g.user['id'],)).fetchall())

    @app.cli.command('run-scheduler')
    @click.option('--once',is_flag=True,help='Check one cycle and exit.')
    def run_scheduler(once):
        """Run the automatic schedule worker; one process per database."""
        from runtime_lock import RuntimeLock
        path=Path(app.config['DATABASE']).with_suffix('.scheduler.lock')
        try:lock=RuntimeLock(path).acquire()
        except RuntimeError as error:raise click.ClickException(str(error)) from None
        try:
            stopping=Event()
            def stop(signum,frame):
                scheduler.stopping=True
                stopping.set()
            previous=signal.signal(signal.SIGTERM,stop) if not once else None
            try:
                while not stopping.is_set():
                    try:
                        scheduler.tick()
                    except Exception:
                        db().rollback();app.logger.exception('Schedule worker cycle failed')
                        if once:
                            raise
                    if once:
                        return
                    stopping.wait(1)
            finally:
                if previous is not None:
                    signal.signal(signal.SIGTERM,previous)
                Path(app.config['DATABASE']).with_suffix('.scheduler.heartbeat').unlink(missing_ok=True)
        finally:
            lock.release()
