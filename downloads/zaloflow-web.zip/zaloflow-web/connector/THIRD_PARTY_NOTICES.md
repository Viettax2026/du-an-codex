# Group member pagination reference

The request layout used by `group-member-page.mjs` was referenced from the
published `@softtynet/zca-js` package, version 2.3.7,
`dist/apis/group/getGroupInfoV2.js` and `dist/constants/protocol.js`.
The application continues to use its pinned
`zca-js` 2.2.0 session, encryption and transport; no fork dependency is installed.

Source: https://registry.npmjs.org/@softtynet/zca-js/2.3.7

The published package includes this license:

MIT License

Copyright (c) 2024 - 2025 RFS-ADRENO, truong9c2208, JustKemForFun

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
